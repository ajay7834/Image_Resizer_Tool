# Image Resizer Tool

## Description
This Python script resizes and converts images in batch using the Pillow library.

## Requirements
- Python 3.x
- Pillow

## Installation
```bash
pip install pillow
```

## Usage
Place images inside the `sample_images/` folder, then run:
```bash
python image_resizer.py
```
The resized images will appear in the `resized_images/` folder.
